#!/bin/bash
gfortran /f90_Files/mc-001.f90 -o /Compiled_Files/mc-001.out
gfortran /f90_Files/mc-002.f90 -o /Compiled_Files/mc-002.out
gfortran /f90_Files/mc-003.f90 -o /Compiled_Files/mc-003.out
gfortran /f90_Files/mc-004.f90 -o /Compiled_Files/mc-004.out
gfortran /f90_Files/mc-005.f90 -o /Compiled_Files/mc-005.out
gfortran /f90_Files/mc-006.f90 -o /Compiled_Files/mc-006.out
gfortran /f90_Files/mc-007.f90 -o /Compiled_Files/mc-007.out
gfortran /f90_Files/mc-008.f90 -o /Compiled_Files/mc-008.out
gfortran /f90_Files/mc-009.f90 -o /Compiled_Files/mc-009.out
gfortran /f90_Files/mc-010.f90 -o /Compiled_Files/mc-010.out
gfortran /f90_Files/mc-011.f90 -o /Compiled_Files/mc-011.out
gfortran /f90_Files/mc-012.f90 -o /Compiled_Files/mc-012.out
gfortran /f90_Files/mc-013.f90 -o /Compiled_Files/mc-013.out
gfortran /f90_Files/mc-014.f90 -o /Compiled_Files/mc-014.out
gfortran /f90_Files/mc-015.f90 -o /Compiled_Files/mc-015.out